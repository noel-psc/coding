from pydantic import BaseModel

class Config(BaseModel):
    """电费查询插件配置"""
    # 默认查询参数
    electric_bill_default_sysid: str = "4"
    electric_bill_default_roomid: str = "4021"
    electric_bill_default_areaid: str = "101"
    electric_bill_default_buildid: str = "13"